particlesJS("particles-js", {
  particles: {
    number: { value: 70 },
    color: { value: "#00ffee" },
    size: { value: 3 },
    line_linked: {
      enable: true,
      color: "#00ffee",
      opacity: 0.4
    },
    move: { speed: 2 }
  }
});
